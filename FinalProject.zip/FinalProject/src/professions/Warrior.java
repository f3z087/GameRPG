package professions;

import java.util.Scanner;

public class Warrior extends Profession {
	
	//Constants for a warrior's attributes
	private static final int WARRIOR_STRENGTH_VALUE = 40;
	private static final int WARRIOR_DEFENSE_VALUE = 20;
	private static final int WARRIOR_HEALTH_POINTS_MAXIMUM = 250;
	private static final double WARRIOR_NORMAL_ACCURACY = .8;
	private static final double WARRIOR_STRONG_ACCURACY = .5;
	
	public Warrior(){
		//Sets a warrior's attributes
		setStrength(WARRIOR_STRENGTH_VALUE);
		setDefense(WARRIOR_DEFENSE_VALUE);
		setHealthPoints(WARRIOR_HEALTH_POINTS_MAXIMUM);
		
		//Sets player name to be user defined
		Scanner consoleScan = new Scanner(System.in);
		System.out.print("Enter your name: ");
		String name = consoleScan.nextLine();
		setPlayerName(name);
		//closing Scanner causes exception to be thrown? consoleScan.close()
	}
	
	//A weaker, but more accurate attack
	public void normalAttack(Profession otherPlayer){
		if (Math.random() <= WARRIOR_NORMAL_ACCURACY){
			System.out.println("Your normal attack landed!");
			int damageDealt = this.getStrength() - otherPlayer.getDefense();
			otherPlayer.setHealthPoints(otherPlayer.getHealthPoints() -damageDealt);
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: "+ otherPlayer.getHealthPoints());
		} else {
			System.out.println("Your normal attack missed!");
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: " + otherPlayer.getHealthPoints());
		}
	}
	
	//A stronger, but less accurate attack
	public void strongAttack(Profession otherPlayer){
		if(Math.random() <= WARRIOR_STRONG_ACCURACY){
			System.out.println("Your strong attack landed!");
			int damageDealt = 2 * this.getStrength() - otherPlayer.getDefense(); 
			otherPlayer.setHealthPoints(otherPlayer.getHealthPoints() - damageDealt);
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: "+ otherPlayer.getHealthPoints());
		} else {
			System.out.println("Your strong attack missed!");
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: "+ otherPlayer.getHealthPoints());
		}
	}
	
	//Displays all the player attributes
	public void showPlayerAttributes(){
		System.out.println(this.getPlayerName() + "'s attributes are: ");
		System.out.println("Profession: " + this.getClass());
		System.out.println("Strength: " + this.getStrength());
		System.out.println("Defense: " + this.getDefense());
		System.out.println("Current Health Points: " + this.getHealthPoints());
		System.out.println("Starting Health Points: " + WARRIOR_HEALTH_POINTS_MAXIMUM);
	}
}

