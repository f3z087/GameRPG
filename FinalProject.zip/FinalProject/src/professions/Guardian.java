package professions;

import java.util.Scanner;

public class Guardian extends Profession {
	
	//Constants for a guardian's attributes
	private static final int GUARDIAN_STRENGTH_VALUE = 30;
	private static final int GUARDIAN_DEFENSE_VALUE = 35;
	private static final int GUARDIAN_HEALTH_POINTS_MAXIMUM = 275;
	private static final double GUARDIAN_NORMAL_ACCURACY = .9;
	private static final double GUARDIAN_STRONG_ACCURACY = .6;
	
	public Guardian(){
		//Sets a warrior's attributes
		setStrength(GUARDIAN_STRENGTH_VALUE);
		setDefense(GUARDIAN_DEFENSE_VALUE);
		setHealthPoints(GUARDIAN_HEALTH_POINTS_MAXIMUM);
				
		//Sets player name to be user defined
		Scanner consoleScan = new Scanner(System.in);
		System.out.print("Enter your name: ");
		String name = consoleScan.nextLine();
		setPlayerName(name);
		//closing Scanner causes exception to be thrown? consoleScan.close()
	}
	
	//A weaker, but more accurate attack
	public void normalAttack(Profession otherPlayer){
		if (Math.random() <= GUARDIAN_NORMAL_ACCURACY){
			System.out.println("Your normal attack landed!");
			int damageDealt = this.getStrength() - otherPlayer.getDefense();
			otherPlayer.setHealthPoints(otherPlayer.getHealthPoints() -damageDealt);
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: "+ otherPlayer.getHealthPoints());
		} else {
			System.out.println("Your normal attack missed!");
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: " + otherPlayer.getHealthPoints());
		}
	}
		
		//A stronger, but less accurate attack
	public void strongAttack(Profession otherPlayer){
		if(Math.random() <= GUARDIAN_STRONG_ACCURACY){
			System.out.println("Your strong attack landed!");
			int damageDealt = 2 * this.getStrength() - otherPlayer.getDefense(); 
			otherPlayer.setHealthPoints(otherPlayer.getHealthPoints() - damageDealt);
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());				
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: "+ otherPlayer.getHealthPoints());
		} else {
			System.out.println("Your strong attack missed!");
			System.out.println(this.getPlayerName() + "'s Health Points: " + this.getHealthPoints());
			System.out.println(otherPlayer.getPlayerName() + "'s Health Points: "+ otherPlayer.getHealthPoints());
		}
	}
	
	//Displays all the player attributes
	public void showPlayerAttributes(){
		System.out.println(this.getPlayerName() + "'s attributes are: ");
		System.out.println("Profession: " + this.getClass());
		System.out.println("Strength: " + this.getStrength());
		System.out.println("Defense: " + this.getDefense());
		System.out.println("Current Health Points: " + this.getHealthPoints());
		System.out.println("Starting Health Ponts: " + GUARDIAN_HEALTH_POINTS_MAXIMUM);
		}
}
