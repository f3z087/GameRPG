//add rules button
//add buttons that show stats


package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import professions.Guardian;
import professions.Profession;
import professions.Warrior;

public class GameGUI extends JFrame {
	
	//Player objects
	private Profession player1 = new Warrior();
	private Profession player2 = new Guardian();
	
	public class P1NormalAttackButton1Listener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			System.out.println(player1.getPlayerName() + " is attacking " + player2.getPlayerName());
			player1.normalAttack(player2); 
			System.out.println();
		}
	}
	
	public class P2NormalAttackButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			System.out.println(player2.getPlayerName() + " is attacking " + player1.getPlayerName());;
			player2.normalAttack(player1);
			System.out.println();
		}
	}
	
	public class P1StrongAttackListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			System.out.println(player1.getPlayerName() + " is attacking " + player2.getPlayerName());
			player1.strongAttack(player2);
			System.out.println();
		}
	}
	
	public class P2StrongAttackButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			System.out.println(player2.getPlayerName() + " is attacking " + player1.getPlayerName());;
			player2.strongAttack(player1);
			System.out.println();
		}
	}
	
	public class P1ShowAttributesButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			player1.showPlayerAttributes();
			System.out.println();
		}
	}
	
	public class P2ShowAttributesButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			player2.showPlayerAttributes();
			System.out.println();
		}
	}
	
	//Constructs game GUI
	public GameGUI(){
		//Name and behavior of the GUI
		super("My Game");
		setSize(500 , 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(new FlowLayout());
		
		
		//Buttons for GUI and their listeners
		JButton p1NormalAttackButton = new JButton("Player 1 Normal Attack");
		JButton p2NormalAttackButton = new JButton("Player 2 Normal Attack");
		JButton p1StrongAttackButton = new JButton("Player 1 Strong Attack");
		JButton p2StrongAttackButton = new JButton("Player 2 Strong Attack");
		JButton p1ShowAttributesButton = new JButton("Player 1 Attributes");
		JButton p2ShowAttributesButton = new JButton("Player 2 Attributes");
		JButton displayRulesButton = new JButton("Game Rules");
		
		P1NormalAttackButton1Listener listener1 = new P1NormalAttackButton1Listener();
		P2NormalAttackButtonListener listener2 = new P2NormalAttackButtonListener();
		P1StrongAttackListener listener3 = new P1StrongAttackListener();
		P2StrongAttackButtonListener listener4 = new P2StrongAttackButtonListener();
		P1ShowAttributesButtonListener listener5 = new P1ShowAttributesButtonListener();
		P2ShowAttributesButtonListener listener6 = new P2ShowAttributesButtonListener();
		
		p1NormalAttackButton.addActionListener(listener1);
		p2NormalAttackButton.addActionListener(listener2);
		p1StrongAttackButton.addActionListener(listener3);
		p2StrongAttackButton.addActionListener(listener4);
		p1ShowAttributesButton.addActionListener(listener5);
		p2ShowAttributesButton.addActionListener(listener6);
		
		
		//Adds components to the container
		add(p1NormalAttackButton);
		add(p2NormalAttackButton);
		add(p1StrongAttackButton);
		add(p2StrongAttackButton);
		add(p1ShowAttributesButton);
		add(p2ShowAttributesButton);
		add(displayRulesButton);
	}
	
	public static void rules(){
		System.out.println("These are the rules.");
	}
	
	
	public static void main(String[] args) {
		GameGUI gameInterface = new GameGUI();
		gameInterface.setVisible(true);
		System.out.println();
		
		
	}

}
